import pygame
# 图片加载测试，其实在pygame开发中，不建议你这么写，建议你使用精灵和精灵组
class Test(object):
    def __init__(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((480,480))
        self.create_images()
       

    def create_images(self): # 图像加载演练，不是项目的一部分
        #背景图片
        self.background_image = pygame.image.load('./res/images/background.png')
        self.background_rect = self.background_image.get_rect()

        #英雄图片
        self.hero_image = pygame.image.load('./res/images/me1.png')
        self.hero_rect = self.hero_image.get_rect()
        self.hero_rect.center = self.background_rect.center

    def start(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            self.screen.blit(self.background_image,self.background_rect)
            self.screen.blit(self.hero_image,self.hero_rect)
            pygame.display.update()
             

if __name__ == '__main__':     
    Test().start()  