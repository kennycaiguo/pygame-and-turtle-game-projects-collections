#游戏面板模块
import pygame
from game_items import *


#面板类
class HUDPanel(object):
    margin =10
    white =(255,255,255)
    gray = (64,64,64)

    reward_score = 100000  #每增加100000分奖励一架飞机
    level2_score = 10000     #达到10000分就进入第二关
    level3_score = 50000     #达到50000分就进入第三关

    record_filename = 'record.txt' # 保存最高分数的文件的路径

    def __init__(self,display_group) -> None:
        """
        面板初始化方法：
        display_group是面板中的精灵要被添加到的精灵组
        """
        self.score = 0
        self.lives_count = 3
        self.level = 1
        self.best_score = 0
        # 加载上一次游戏的最好成绩
        self.load_best_score()
    
        # 图像精灵
        #1.状态精灵
        self.status_sprite = StatusButton(('pause_nor.png','resume_nor.png'),display_group)
        self.status_sprite.rect.topleft = (self.margin,self.margin)

        #2.炸弹精灵
        self.bomb_sprite = GameSprite('bomb.png',0,display_group)
        # 调整bomb_sprite的位置
        self.bomb_sprite.rect.x = self.margin 
        self.bomb_sprite.rect.bottom = SCREEN_RECT.bottom - self.margin

        #3.生命计数精灵
        self.lives_sprite = GameSprite('life.png',0,display_group)
        # szlives_sprite的位置
        self.lives_sprite.rect.right = SCREEN_RECT.right-self.margin
        self.lives_sprite.rect.bottom = SCREEN_RECT.bottom - self.margin

        #4.创建标签精灵
        # 4.1数字标签
        # 4.1.1 分数标签
        self.score_label = Label("%d" % self.score,32,self.gray,display_group) 
        self.score_label.rect.midleft = (self.status_sprite.rect.right + self.margin,
                                           self.status_sprite.rect.centery)
        
        # 4.1.2 炸弹计数标签
        self.bomb_label = Label("X 3",32,self.gray,display_group )
        self.bomb_label.rect.midleft = (self.bomb_sprite.rect.right+self.margin,
                                           self.bomb_sprite.rect.centery)

        # 4.1.3 生命值标签,这个标签的位置笔记特别，它会占用lives_sprite的位置，
        # 然后lives_sprite的位置需要使用它的位置来重新计算
        self.lives_label = Label("X %d" % self.lives_count,32,self.gray,display_group)
        self.lives_label.rect.midright = (SCREEN_RECT.right - self.margin,
                                          self.bomb_label.rect.centery)
         
        #修改 lives_sprite的位置
        self.lives_sprite.rect.right = self.lives_label.rect.left - self.margin

        #注意：在游戏正常运行时，最好成绩标签，状态标签和  提示标签是隐藏的，游戏状态，他们才显示
        # 4.1.4 最好成绩标签
        self.best_label = Label("Best: %d" % self.best_score,36,self.white)
       
        # 4.1.5 状态标签
        self.status_label = Label("Game Playing",48,self.white)
        
        # 4.1.6 提示标签
        self.tip_label = Label("Press SpaceBar To Pause Game",22,self.white)
        
       
    # 显示炸弹数量的方法
    def show_bomb(self,count):
        # 修改文字
        self.bomb_label.set_text("X %d" % count)
        # 修改位置
        self.bomb_label.rect.midleft = (self.bomb_sprite.rect.right + self.margin,
                                        self.bomb_sprite.rect.centery)
        
    def show_lives(self):
        self.lives_label.set_text("X %d" % self.lives_count)  

        #调整 lives_label的位置
        self.lives_label.rect.midright = (SCREEN_RECT.right - self.margin,
                                          self.bomb_label.rect.centery)
         
        #调整 lives_sprite的位置
        self.lives_sprite.rect.right = self.lives_label.rect.left - self.margin  

    # 定义一个增加分数的方法
    def increase_score(self,enemy_score):
        #1.先用一个变量来累计每一次的得分
        score = self.score + enemy_score # 这个分数需要一直增加

        #2.每累计一次，就需要判断是否奖励一条命，是很有技巧的,其实还有别的方法，如：只要这个score能被100000整除就可以了
        if score // self.reward_score !=self.score // self.reward_score:
           self.lives_count +=1 #奖励一条命，也就是多一架飞机
           self.show_lives() # 获取到奖励后需要更新生命值

        # 更新自己的分数
        self.score = score 
        #3.每累计一次，都要和上一次的最好成绩比较,只要这个成绩比原来的最好成绩大，就把它设置为最好成绩，否则不设置
        self.best_score = score if score > self.best_score else self.best_score 

        #4.每累计一次，都要判断是否升级 
        if  score < self.level2_score:
            level = 1
        elif score < self.level3_score:
            level = 2   
        else:
            level = 3  

        is_upgrade = level !=self.level    
        self.level = level

        # 5.每累计一次，都需要修改分数标签的内容和位置
        self.score_label.set_text("%d" % self.score)
        self.score_label.rect.midleft = (self.status_sprite.rect.right + self.margin,
                                           self.status_sprite.rect.centery)
        return is_upgrade
    

    # 保存最好成绩的方法
    def save_best_score(self):
        with open(self.record_filename,'w') as f:
            f.write('%d' % self.best_score)

    def load_best_score(self):
         try: 
            with open(self.record_filename,'r') as f:    
                self.best_score = int(f.read())  
                print(f'上一次最高分数是{self.best_score}')
         except (FileNotFoundError,ValueError):
             print('读取record.txt文件出错,文件不存在或者内容为空...')        
             
    # 暂停游戏的方法,必须在游戏没有介绍的前提下才有效
    def panel_pause(self,is_game_over,display_group):
        #1.首先需要判断是否把最好成绩标签，状态标签和  提示标签添加到了精灵组，如果是，直接返回
        if display_group.has(self.best_label,self.status_label,self.tip_label):
            return

        # 2.根据游戏是否介绍来调整标签的文字
        text = "Game Over!" if is_game_over else "Game Paused!" 
        tip = 'Press SpaceBar To'
        tip += ' Play Again' if is_game_over else " Continue"

        # 3.给标签设置对应的文字
        self.status_label.set_text(text)
        self.best_label.set_text("Best Score: %d" % self.best_score)
        self.tip_label.set_text(tip)

        # 4.调整标签位置
        self.best_label.rect.center = SCREEN_RECT.center
        self.status_label.rect.midbottom = (self.best_label.rect.centerx,
                                            self.best_label.rect.y - 2 * self.margin)
        
        self.tip_label.rect.midtop = (self.best_label.rect.centerx,
                                    self.best_label.rect.bottom + 8 * self.margin)
        
        # 5.添加标签到精灵组
        display_group.add(self.best_label,self.status_label,self.tip_label)

        # 6.状态精灵切换状态
        self.status_sprite.switch_status(True)

    # 从暂停状态恢复
    def panel_resume(self,display_group):
        # 1.隐藏 最好成绩标签，状态标签和  提示标签添只需要把他们从精灵组里面删除即可
        display_group.remove(self.best_label,self.status_label,self.tip_label) 
        # 2.需要切换状态精灵的状态
        self.status_sprite.switch_status(False) 

    # 重置面板内容的功能
    def reset_panel(self):
        #重置数据
        self.score = 0
        self.lives_count = 3

        #重置精灵数据
        self.increase_score(0) # 可以在这个方法里面计算level，设置最好成绩标签，状态标签和  提示标签添等等
        self.show_lives() #重置生命值
        self.show_bomb(3) #重置炸弹数量
        
