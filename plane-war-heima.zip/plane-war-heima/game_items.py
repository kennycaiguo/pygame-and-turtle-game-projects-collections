#封装游戏元素对应的类
from typing import Any
import pygame
import random

# 定义全局常量
SCREEN_RECT = pygame.Rect(0,0,480,700)                                  #游戏屏幕矩形
FRAME_INTERVAL = 10                                                     # 逐帧动画间隔帧数
HERO_BOMB_COUNT = 3                                                     # 英雄飞机的炸弹数量
HERO_DEFAULT_MID_BUTTOM = (SCREEN_RECT.centerx,SCREEN_RECT.bottom - 90) #英雄默认初始位置
HERO_DEAD_EVENT = pygame.USEREVENT                                      # 定义英雄牺牲事件
HERO_POWER_OFF_EVENT = pygame.USEREVENT+1                               # 定义英雄无敌数据结束事件
HERO_FIRE_EVENT = pygame.USEREVENT+2                                    #定义游戏飞机发射子弹的事件
THROW_SUPPLY_EVENT = pygame.USEREVENT+ 3                                #投放道具事件
BULLET_ENHANCE_OFF_EVENT = pygame.USEREVENT+ 4                          #双排子弹失效事件


class GameSprite(pygame.sprite.Sprite):
    res_path = './res/images/'

    def __init__(self,image_name,speed, *groups) -> None:
        super().__init__(*groups)
        self.image = pygame.image.load(self.res_path + image_name) #加载图片
        self.rect = self.image.get_rect() # 获取图片的矩形区域并且保存起来
        self.speed = speed # 接收传递进来的速度值
        # 需要一个遮罩属性用来做高效碰撞检测
        self.mask = pygame.mask.from_surface(self.image) # 来用精灵的图片来创建遮罩

    def update(self, *args) -> None:
        # super().update(*args)  
        """默认在垂直方向移动"""   
        self.rect.y += self.speed

class BackgroundSprite(GameSprite):
    # 需要在初始化的时候给他传递应该状态,is_alt==True说明这个背景精灵需要显示在窗口的顶部
    def __init__(self, is_alt ,*groups) -> None:
        super().__init__('background.png', 1, *groups)
        if is_alt:
            self.rect.y = -self.rect.h

    def update(self, *args) -> None:
        super().update(*args)    
        # 图片滚出边界的处理：如果图片已经滚动到了窗口的底部，
        # 立即让他回到窗口的最上面，然后重新往下滚动
        if self.rect.y > self.rect.h:
            self.rect.y = -self.rect.h

class StatusButton(GameSprite):
    def __init__(self, image_names, *groups) -> None:
        """image_names是一个元组，元组的0下标必须是一张暂停的图片，元组的1下标必须是一张播放的图片"""
        super().__init__(image_names[0],0,*groups)
        # 准备2张图片供切换
        self.images = [pygame.image.load(self.res_path+name) for name in image_names]

    def switch_status(self,is_pause):
        """切换状态的方法"""
        #根据状态切换图片
        self.image =self.images[1 if is_pause  else 0] # 仿三目运算符


#标签精灵类
class Label(pygame.sprite.Sprite):
    font_path = './res/font/MarkerFelt.ttc' # 字体文件的存放路径

    def __init__(self,text,size,color, *groups) -> None:
        super().__init__(*groups)
        # 创建字体，使用我们提供的字体文件
        self.font = pygame.font.Font(self.font_path,size)
        self.color = color # 文字颜色
        # 精灵属性
        self.image = self.font.render(text,True,self.color)
        self.rect = self.image.get_rect()

    def set_text(self,text):
        """设置字体方法"""
        self.image = self.font.render(text,True,self.color)
        self.rect = self.image.get_rect()

# 飞机类
class Plane(GameSprite):
    def __init__(self, hp,speed,value,wav_name,normal_names,hurt_name,destroy_names, *groups) -> None:
        """初始化方法
        hp:            血量
        speed:         飞行速度
        value:         分值，也就是摧毁一个得到多少分
        wav_name:      对应的音效文件
        normal_names:  正常状态下的逐帧动画图片列表
        hurt_name:     受伤图片，此时飞机并没有被摧毁
        destroy_names: 飞机爆炸效果逐帧动画的图片列表
        *groups:       需要添加到的精灵组 
        """
        super().__init__(normal_names[0], speed, *groups)  
        self.hp = hp 
        self.max_hp = hp
        self.value = value
        self.wav_name = wav_name
        # 正常状态图像列表
        self.normal_images = [pygame.image.load(self.res_path+name) for name in normal_names] #列表推导式
        # 正常状态图像索引
        self.normal_index  = 0
        # 加载受伤图片
        self.hurt_image = pygame.image.load(self.res_path+hurt_name)
        # 加载摧毁图片列表
        self.destroy_images = [pygame.image.load(self.res_path+name) for name in destroy_names]
        # 摧毁图片索引
        self.destroy_index = 0

    # 重置飞机的方法
    def reset_plane(self):
        #1.利用max_hp重置hp
        self.hp = self.max_hp
        #2.把normal_index归零]
        self.normal_index = 0
        #3.把destroy_index归零
        self.destroy_index = 0
        #4.把图片改为正常图片的第一张
        self.image = self.normal_images[0] 

    # update方法      
    def update(self,*args):
        """更新状态，准备下一次需要显示的内容"""
        # 判断是否需要更新，只需要判断args[0]是否位True，注意*args是可变长参数
        if not args[0]: # 如果为False就不更新，直接return
            return
        #True就更新
        #根据血量hp来切换需要显示的图片，有几种情况
        if self.hp == self.max_hp: # 说明没有受伤，显示正常图片即可
            self.image = self.normal_images[self.normal_index]
            # 计算下一张图片索引，注意下标不能越界
            count = len(self.normal_images)
            self.normal_index = (self.normal_index + 1)%count # 利用取余数的方法来处理越界问题
        elif self.hp >0 : # 受伤了，但是还没有被摧毁
            self.image = self.hurt_image #显示为受伤状态
        else: #进入摧毁中的状态，播放摧毁动画
            #判断是否播放到了最后一张图片，如果是就是完全被摧毁了
            if self.destroy_index < len(self.destroy_images):
                self.image = self.destroy_images[self.destroy_index]
                self.destroy_index += 1
                
            else: #完全摧毁，需要重置飞机
                self.reset_plane()    

# 敌机类
class Enemy(Plane):
    def __init__(self, kind,max_speed, *groups) -> None:
        self.kind = kind
        self.max_speed = max_speed
        if kind == 0: # 小敌机
            super().__init__(1, max_speed, 1000, 'enemy1_down.wav', 
                             ["enemy1.png"], "enemy1.png",
                             ['enemy1_down%d.png'% i for i in range(1,5)],
                             *groups)
        elif kind == 1: # 中敌机
            super().__init__(6, max_speed, 6000, 'enemy2_down.wav', 
                             ["enemy2.png"], "enemy2_hit.png",
                             ['enemy2_down%d.png'% i for i in range(1,5)],
                             *groups)  
        elif kind == 2: # 大敌机
            super().__init__(15, 1, 15000, 'enemy3_down.wav', 
                             ["enemy3_n1.png","enemy3_n2.png"], "enemy3_hit.png",
                             ['enemy3_down%d.png'% i for i in range(1,7)],
                             *groups) 
             
        # 随机设置飞机位置，要不然飞机就重叠在一起了 
        self.reset_plane()   
            
    def reset_plane(self):
       super().reset_plane() #先调用父类的重置方法
       """敌机的数据重置代码"""
       x = random.randint(0,SCREEN_RECT.w - self.rect.w) 
       y = random.randint(0,SCREEN_RECT.h - self.rect.h) - SCREEN_RECT.h # 设置到屏幕外面

       self.rect.topleft = (x,y)

       #设置速度
       self.speed = random.randint(1,self.max_speed)

    def update(self, *args): #其实就是在父类的基础上添加飞机出界处理
        super().update(*args)   # 调用父类的update方法
        #判断是否被摧毁，如果没有就继续更新位置
        if self.hp > 0: 
            self.rect.y += self.speed
        if self.rect.y >= SCREEN_RECT.h: #出界了，就要重新设置位置
            self.reset_plane()

class Hero(Plane):
    def __init__(self, *groups) -> None:
        self.is_power = False                     # 是否无敌
        self.bomb_count = HERO_BOMB_COUNT         # 英雄飞机的炸弹数量
        self.bullets_kind = 0                      # 子弹类型
        self.bullets_group = pygame.sprite.Group() # 子弹精灵组
        # 调用父类的初始化方法
        super().__init__(1000, 5, 0, 'me_down.wav',['me1.png','me2.png'],'me1.png',
                    ['me_destroy_%d.png' % i for i in range(1,5)], *groups)

        # 设置英雄飞机默认位置
        self.rect.midbottom = HERO_DEFAULT_MID_BUTTOM
        # 用定时器发送英雄发射子弹事件
        pygame.time.set_timer(HERO_FIRE_EVENT,200)

    def update(self, *args):
        """
        在这里args[0]是一个标记表明是否需要更新帧动画,
        args[1]就是水平移动的方向基数，
        args[2]就是垂直移动方向基数
        """
        super().update(*args)  
        # 为了保证代码的正确执行，需要两个条件：首先传递进来的args的长度必须是3，其次英雄飞机的血量必须大于0
        if len(args) != 3 or self.hp <= 0: #不符合条件就返回
            return
        # 根据args[1]来设置英雄飞机的水平移动方向
        self.rect.x += args[1] * self.speed
        self.rect.x = 0 if self.rect.x < 0 else self.rect.x #左边出界处理
        if self.rect.right > SCREEN_RECT.right:
             self.rect.right = SCREEN_RECT.right # 右边出界处理

        # 根据args[2]来设置英雄飞机的垂直移动方向
        self.rect.y += args[2] * self.speed
        self.rect.y = 0 if self.rect.y < 0 else self.rect.y # 上边出界处理
        if self.rect.bottom > SCREEN_RECT.bottom:
             self.rect.bottom = SCREEN_RECT.bottom # 下边出界处理

    def blowup(self,enemies_group):
        # 先判断有没有炸弹
        if self.bomb_count <= 0 or self.hp <=0:
            return 0 # 没有炸弹， 炸不了,返回0分
        
        self.bomb_count -= 1  # 每炸一次，炸弹数需要减少1
        score = 0
        count = 0
        # 炸掉使用敌机并且获取分数
        for enemy in enemies_group.sprites():
            # 在炸飞机之前需要先判断它是否在屏幕里面,如果是才能炸
            if enemy.rect.bottom > 0:
                score += enemy.value # 累计得分
                enemy.hp = 0 # 搞死敌人
                count += 1 # 计算器累计

        print('炸毁了 %d 架敌机' % count)    
        # 返回获取的累计分数    
        return score 
       
    def reset_plane(self):
        super().reset_plane()
        self.is_power = True
        self.bomb_count = HERO_BOMB_COUNT
        self.bullets_kind = 0
        
        #发布英雄牺牲事件，让游戏主逻辑更新面板
        pygame.event.post(pygame.event.Event(HERO_DEAD_EVENT))  
        # 给英雄飞机设置3秒的无敌时间
        pygame.time.set_timer(HERO_POWER_OFF_EVENT,3000) # 超过三秒就没有无敌效果

    # 英雄飞机发射子弹的方法
    def fire(self,display_group):
        # 先要准备子弹需要添加到的精灵组
        groups = (self.bullets_group,display_group)

        # 测试子弹增强效果
        # self.bullets_kind = 1
        # print("xxxxxxx")
        # 创建子弹精灵
        for i in range(3):
            bullet1 = Bullet(self.bullets_kind,*groups)

            #计算子弹垂直位置
            y = self.rect.y - i*15

            #判断子弹类型
            if self.bullets_kind == 0: #单排
                bullet1.rect.midbottom = (self.rect.centerx,y)
            else: #双排
                 # 把第一排子弹的x坐标从中间往左边移动20像素
                 bullet1.rect.midbottom = (self.rect.centerx - 20,y)    
                 #再创建一颗子弹
                 bullet2 = Bullet(self.bullets_kind,*groups)
                  # 把第二排子弹的x坐标从中间往右边边移动20像素
                 bullet2.rect.midbottom = (self.rect.centerx + 20,y)    
        

# 子弹类
class Bullet(GameSprite):
    def __init__(self, kind, *groups) -> None:
        # image_name = 'bullet.png' if kind==0 else 'bullet2.png'
        image_name = 'bullet1.png' if kind==0 else 'bullet2.png'
        super().__init__(image_name, -12, *groups) # -12表示子弹往上移动，速度是12
        self.damage = 1  #杀伤力

    def update(self, *args) -> None:
        super().update(*args)    
        # 子弹飞出窗口的处理，需要销毁
        if self.rect.bottom < 0:
            self.kill()   # 调用精灵自身的kill方法来销毁它

# 道具类，可以增加炸弹数量或者把子弹变为双排，维持20秒钟
class Supply(GameSprite):
    def __init__(self, kind, *groups) -> None:
        # 根据道具类型的不同加载不同图片文件
        image_name = "bomb_supply.png" if kind == 0 else 'bullet_supply.png'
        super().__init__(image_name, 5, *groups)
        self.kind = kind
        # 根据道具类型的不同加载不同音效文件
        self.wav_name = "get_%s.wav" % ("bomb" if kind == 0 else "bullet")
        
        # 根据游戏规则，创建完道具对象后，需要把他们放在游戏窗口的下方
        self.rect.top = SCREEN_RECT.h

    def update(self, *args) -> None:
        # 需要先判断，如果道具已经在窗口下方，不需要更新
        if self.rect.y > SCREEN_RECT.h:
            return 
        super().update(*args)  
    
    # 抛出道具的方法
    def throw_supply(self):
        self.rect.bottom = 0 # 将道具移动到窗口顶部
        # 计算道具随机出现的位置的x左边
        self.rect.x = random.randint(0,SCREEN_RECT.w - self.rect.w)
