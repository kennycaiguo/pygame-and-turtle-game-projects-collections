#封装音乐的程序
import pygame
import os

class MusicPlayer(object):
    res_path = './res/sound/' # 存放音乐文件

    def __init__(self,music_file) -> None:
        """初始化方法"""
        #1. 加载背景音乐
        pygame.mixer.music.load(self.res_path + music_file)
        pygame.mixer.music.set_volume(0.2) # 设置音量
       
        #2.加载音效
        self.sound_dict = {}

        files = os.listdir(self.res_path) # 读取音乐文件夹里面的所有文件
        for file_name in files:
            if file_name == music_file:
                continue    # 背景音乐在游戏一开始就加载了，不用再加载
            self.sound_dict[file_name] = pygame.mixer.Sound(self.res_path+file_name) # 加载音效并保存



    @staticmethod    
    def play_music(): # 播放音乐的方法,设置为静态方法
        pygame.mixer.music.play(-1)

    @staticmethod    
    def pause_music(is_pause):  # 暂停播放方法可以暂停和取消暂停播放,这个方法的设计还是很巧妙的。
        if is_pause: #如果暂停标记为True，暂停播放音乐
            pygame.mixer.music.pause()
        else: # 否则取消暂停，继续播放
            pygame.mixer.music.unpause()
    
    # 播放音效的方法
    def play_sound(self,wav_file):
        self.sound_dict[wav_file].play()