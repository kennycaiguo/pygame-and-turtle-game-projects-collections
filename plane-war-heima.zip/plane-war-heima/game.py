#游戏主程序
import pygame
import random
from game_items import *
from game_hud import *
from game_music import *


class Game(object):
    def __init__(self) -> None:
       #1.游戏主窗口
       self.main_window = pygame.display.set_mode(SCREEN_RECT.size)
       #设置窗口标题
       pygame.display.set_caption('飞机大战')

       #2.游戏状态属性
       self.is_game_over = False #游戏结束标记
       self.is_pause = False    #游戏暂停标记

       #3.创建精灵组，3个精灵组：all_group,enemies_group,supplies_group
       self.all_group = pygame.sprite.Group() # 存放所有精灵的精灵组
       self.enemies_group = pygame.sprite.Group() # 敌人精灵组
       self.supplies_group = pygame.sprite.Group() # 补给精灵组或者道具精灵组
       
       #4.创建精灵
       #创建背景精灵，需要2个精灵否则无法实现连续滚动效果，默认向下移动,我们将他们添加到all_group中
       #写法1
    #    BackgroundSprite(False,self.all_group) #默认在窗口里面显示 
    #    BackgroundSprite(True,self.all_group)  #默认在窗口顶部外面显示
       #写法2
       self.all_group.add( BackgroundSprite(False),BackgroundSprite(True))
       
       #创建游戏控制面板
       self.hud_panel = HUDPanel(self.all_group)

       #创建英雄精灵,有速度的
       self.hero = Hero(self.all_group)
       #在创建英雄飞机后修改炸弹数量、
       self.hud_panel.show_bomb(self.hero.bomb_count)
       
       # 初始化敌机
       self.creat_enemies()

       # 创建道具
       self.creat_supplies()

       #5.音乐播放器
       self.player = MusicPlayer('game_music.ogg')
       self.player.play_music()
    

    def reset_game(self):
      """重置游戏"""
      self.is_game_over = False #游戏结束标记
      self.is_pause = False    #游戏暂停标记
      self.hud_panel.reset_panel() #重置显示面板
      # 重置英雄飞机的位置
      self.hero.rect.midbottom = HERO_DEFAULT_MID_BUTTOM
      #销毁所有的敌机
      for enemy in self.enemies_group.sprites():
          enemy.kill()
      # 销毁所有子弹
      for bullet in self.hero.bullets_group.sprites():
          bullet.kill()    
      # 重新创建敌机
      self.creat_enemies()
          

    def creat_enemies(self):
        """创建敌机"""
        # 先获取敌人精灵组的精灵数量
        count = len(self.enemies_group.sprites())
        # 再定义精灵需要添加到的精灵组，有all_group和enemies_group
        groups = (self.all_group,self.enemies_group)
        #根据游戏级别和敌机数量来创建敌机
        if self.hud_panel.level ==1 and count == 0: # 关卡1
            for i in range(16):
                Enemy(0,3,*groups)
        elif self.hud_panel.level ==2 and count == 16: # 关卡2
            # 1.先给敌机加速
            for enemy in self.enemies_group.sprites():
                enemy.max_speed = 5  # 此时只有一种敌机
            # 2.创建敌机
            for i in range(8):
                Enemy(0,5,*groups) # 创建8架小飞机
            for i in range(2):    
                Enemy(1,1,*groups) # 创建2架中飞机 
        elif self.hud_panel.level ==3 and count == 26: # 关卡3
            # 1.先给敌机加速
            for enemy in self.enemies_group.sprites():
                enemy.max_speed = 7 if enemy.kind == 0 else 3 #此时有两种敌机
            # 2.创建敌机
            for i in range(8):
                Enemy(0,5,*groups) # 创建8架小飞机
            for i in range(2):    
                Enemy(1,1,*groups) # 创建2架中飞机 
            for i in range(2):    
                Enemy(2,1,*groups) # 创建2架大飞机 


    def creat_supplies(self):
        """创建道具"""
        Supply(0,self.supplies_group,self.all_group)
        Supply(1,self.supplies_group,self.all_group)
        # 每隔30秒发送一次抛出道具事件
        pygame.time.set_timer(THROW_SUPPLY_EVENT,5000) # 这里是为了测试方便把时间间隔暂时改为10秒
        # pygame.time.set_timer(THROW_SUPPLY_EVENT,30000)


    def start(self):
        """开始游戏"""
        #创建游戏时钟
        clock = pygame.time.Clock()
        # 定义应该逐帧动画计算器，用来控制逐帧动画的播放速度
        frame_counter = 0
        #游戏主循环
        while True:
            # 游戏循环的第一件事就是判断游戏是否结束，当玩家的飞机数量是0，就可以
            self.is_game_over = self.hud_panel.lives_count == 0
            #监听事件，调用event_handler方法
            if self.event_handler(): #返回True说明用户点击了关闭按钮
                self.hud_panel.save_best_score() #游戏介绍之前需要把最好成绩保存到record.txt文件中
                return

            # 根据游戏状态切换界面显示的内容
            if self.is_game_over:
                self.hud_panel.panel_pause(True,self.all_group) # Game over了，游戏需要停止注意第一个参数和暂停不一样

            elif self.is_pause:
                self.hud_panel.panel_pause(False,self.all_group) #如果暂停标志位真，就暂停游戏

            else:
                self.hud_panel.panel_resume(self.all_group) # 从暂停状态恢复

                # 获取当前时刻的按键元组
                keys = pygame.key.get_pressed()
               
                # 我们利用一个比较简便的方法来判断水平移动的方向，
                # 就是用keys[pygame.K_RIGHT]-keys[pygame.K_LEFT]
                move_hor = keys[pygame.K_RIGHT]-keys[pygame.K_LEFT]
                # 同理判断垂直移动的方向，就是用keys[pygame. pygame.K_DOWN]-keys[ pygame.K_UP]
                move_ver = keys[pygame.K_DOWN]-keys[ pygame.K_UP]

                # 碰撞检测方法的调用
                self.check_collide()
                 
                # 控制逐帧动画播放速度
                frame_counter = (frame_counter + 1) % FRAME_INTERVAL 
                self.all_group.update(frame_counter == 0,move_hor,move_ver)  # 这里也需要传递移动方向

            #绘制所有精灵
            self.all_group.draw(self.main_window)     

            #刷新界面
            pygame.display.update() 

            #设置游戏的刷新频率
            clock.tick(60)


    def event_handler(self):
        """事件监听"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT: #处理点击窗口的关闭按钮的退出事件
                return True
            elif event.type == pygame.KEYDOWN and event.key==pygame.K_ESCAPE: # 按esc键程序也会退出
                return True
            elif event.type == pygame.KEYDOWN and event.key==pygame.K_SPACE: # 按空格键
                #如果游戏已经结束
                if self.is_game_over:
                    self.reset_game() #重置游戏
                else:
                    self.is_pause = not self.is_pause # 如果没有结束，就可以进行暂停和继续的切换
                    self.player.pause_music(self.is_pause) # 背景音乐状态切换

            # 当游戏没有暂停也没有结束，用户按下b键才有效，否则没有效果
            # 引爆炸弹监听事件，用户按下b键会引爆一个炸弹把所有敌机都炸掉，然后炸弹数量要减少1
            if not self.is_game_over and not self.is_pause:
                if event.type == pygame.KEYDOWN and event.key==pygame.K_b:
                   if self.hero.hp > 0 and self.hero.bomb_count >0: #必须保证活着而且有炸弹
                        self.player.play_sound('use_bomb.wav') # 播放引爆炸弹的音效
                   score = self.hero.blowup(self.enemies_group) # 炸弹屏幕上所有敌人并且获取总分
                   # 更新面板的炸掉显示数量
                   self.hud_panel.show_bomb(self.hero.bomb_count)
                   # 加分并且检查是否升级
                   if self.hud_panel.increase_score(score):
                       # 如果升级，需要创建更多敌机
                       self.creat_enemies()

                elif event.type == HERO_DEAD_EVENT:
                    self.hud_panel.lives_count -= 1 # 每死亡一架飞机，生命数量减少1
                    self.hud_panel.show_lives() # 更新生命标签的显示数据
                    self.hud_panel.show_bomb(self.hero.bomb_count) # 需要更新炸弹的显示数量

                elif event.type == HERO_POWER_OFF_EVENT:
                    self.hero.is_power = False # 过滤无敌时间，响应将无敌标志设置为False
                    # 然后需要关闭定时器
                    pygame.time.set_timer(HERO_POWER_OFF_EVENT,0)

                elif event.type == HERO_FIRE_EVENT:
                    self.player.play_sound('bullet.wav') # 播放发射子弹的音效
                    self.hero.fire(self.all_group)
                # 投放道具事件处理
                elif event.type == THROW_SUPPLY_EVENT:
                    self.player.play_sound('supply.wav') # 播放道具音效
                    supply = random.choice(self.supplies_group.sprites()) # 随机获取一个道具
                    supply.throw_supply() # 把它投放出去  

                elif event.type == BULLET_ENHANCE_OFF_EVENT:
                    # 1.把子弹的类改为普通子弹，也就是0
                    self.hero.bullets_kind = 0
                    # 2.关闭子弹失效事件定时器
                    pygame.time.set_timer(BULLET_ENHANCE_OFF_EVENT,0)

        return False #其他情况都不会退出程序         

    def check_collide(self):
        """碰撞检测"""
        # 根据游戏的规则，需要检测英雄飞机是否是在3秒的无敌时间内，如果不是，继续往下执行
        # 检测英雄飞机和敌机方式碰撞
        if not self.hero.is_power:
            # 获取于英雄飞机发生碰撞的敌机。是一个列表
            collided_enemies = pygame.sprite.spritecollide(self.hero,
                                                        self.enemies_group,False,
                                                            pygame.sprite.collide_mask)
            # 过滤掉爆炸敌机残骸
            collided_enemies = list(filter(lambda x: x.hp > 0,collided_enemies))

            if collided_enemies:
                self.player.play_sound(self.hero.wav_name) # 播放英雄飞机爆炸的音效
                self.hero.hp = 0 # 只要有碰撞，英雄飞机被摧毁
            # 同时碰撞到的所有敌机也会被摧毁
            for enemy in collided_enemies:
                enemy.hp = 0

            # 子弹和敌机的碰撞检测
            #1.获取被撞击的敌机集合，是一个字典，key是敌机，value是击中敌机的字典列表
            hit_enemies = pygame.sprite.groupcollide(self.enemies_group,self.hero.bullets_group,
                                                           False,False,pygame.sprite.collide_mask)
            # 2.遍历集合，判断有没有被摧毁的敌机
            for enemy in hit_enemies:
                # 如果是被摧毁的敌机，就不需要处理
                if enemy.hp <= 0:
                    continue
                # 如果敌机没有被摧毁，遍历敌机对应的子弹列表
                for bullet in hit_enemies[enemy]:
                    bullet.kill() #销毁子弹
                    enemy.hp -= bullet.damage
                    if enemy.hp > 0: # 如果敌机没有被销毁，继续遍历下一颗子弹
                        continue
                    # 当前这一颗子弹以经把敌机摧毁了,加分并且判断是否升级
                    if self.hud_panel.increase_score(enemy.value):
                        #如果升级，
                        # 1.播放升级音效
                        self.player.play_sound('upgrade.wav') # 播放升级的音效
                        #2.需要创建更多敌机
                        self.creat_enemies()
                    # 播放敌机爆炸音效   
                    self.player.play_sound(enemy.wav_name) 
                    # 这架飞机已经被摧毁就不需要遍历下一颗子弹了
                    break    
            # 英雄飞机拾取道具
            supplies = pygame.sprite.spritecollide(self.hero,self.supplies_group,False,
                                                          pygame.sprite.collide_mask)
            if supplies:
                supply = supplies[0]
                # 播放使用道具音效
                self.player.play_sound(supply.wav_name) # 根据道具类型播放对应的音效
                # 将道具放到窗口下面
                supply.rect.y = SCREEN_RECT.h
                # 判断道具类型
                if supply.kind == 0: # 是炸弹，需要增加屏幕上炸弹的数量和英雄飞机炸弹的数量
                    self.hero.bomb_count += 1
                    self.hud_panel.show_bomb(self.hero.bomb_count)
                else: # 是子弹增强效果
                    # 把子弹类型改为双排
                    self.hero.bullets_kind = 1
                    # 每隔20秒发送子弹增强效果关闭事件
                    pygame.time.set_timer(BULLET_ENHANCE_OFF_EVENT,20000)

if __name__ == '__main__':
    #初始化游戏
    pygame.init()
    #开始游戏
    Game().start()
    #释放游戏资源
    pygame.quit()